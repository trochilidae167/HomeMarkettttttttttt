﻿using HomeMarket.Common;
using HomeMarket.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace HomeMarket.Controllers.APIController
{
    public class GetNhaCungUngAPIController : ApiController
    {
        private HomeMarketDbContext db = new HomeMarketDbContext();
        public class KhachHangOnline
        {
            public double X { get; set; }
            public double Y { get; set; }
        }
        [HttpPost]
        public IQueryable<NhaCungUng> PostNhaCungUng(KhachHangOnline khachHangOnline)
        {
            List<int> list = FindSupplier.LookingForSupplier(khachHangOnline.X, khachHangOnline.Y);
            var ncu = db.NhaCungUng.Where(x=> list.Contains(x.Id));
            return ncu; 
        }
    }
}
